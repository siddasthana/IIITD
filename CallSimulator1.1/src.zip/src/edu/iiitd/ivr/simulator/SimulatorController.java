package edu.iiitd.ivr.simulator;


import edu.iiitd.ivr.simulator.model.CallEvents;
import edu.iiitd.ivr.simulator.model.Event;
import java.io.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;


/**
 * This class represents the controller component of 
 * Simulator in MVC paradigm.
 * @author siddhartha
 */
public class SimulatorController {
            /**
             * VoIP extension to dial.
             */
	 int number = 30132100;
         /**
          * IP address of SIP server.
          */
	 String server_ip = "192.168.1.130";
         /**
          * Path of log file containing call data.
          */
     String logfile="/home/ivr/media/"
			+ "Mtech.log";	 
	 String sip_url = "";
	 PrintWriter pw;
	 InputStreamReader is;
	 String level = "";
         /**
          * Tree structure to store data of IVR menu option
          * in hierarchical fashion.
          */
	 Tree<String> IVRmenu = new Tree<String>();
	 Connection con = null;
	 /**
          * Timer object to schedule call events.
          */
         Timer timer;
         /**
          * List structure to store calls in sequential
          * order.
          */
	 List<CallEvents> callList = new ArrayList<CallEvents>();

	class outpt implements Runnable {
		public void run() {
			try {
				while (is.ready()) {
					System.out.print(is.read());
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
         * A single method to load IVR menu and call
         * events into memory. This method explicitly
         * calls loadIVRMenu() and loadCallEvents().
	 */
	public void loadData(){
		loadIVRMenu();
		loadCallEvents();
		
	}
        /**
         * Method to start simulation.
         */
        public void main() {
		// TODO Auto-generated method stub
		// System.out.println("Calling....");
		// startCall();
		int timecorrection = 0;
		timer = new Timer();
		for (CallEvents e : callList) {
			timer.schedule(new Event(this, "call"), timecorrection * 1000);
			int i = 0;
			for (Integer key : e.key) {
				timer.schedule(new Event(this, key),
						(e.time.get(i) + timecorrection) * 1000);
				i++;
			}
			timer.schedule(new Event(this, "end"),
					(e.time.get(i - 1) + 10 + timecorrection) * 1000);
			timecorrection = e.time.get(i - 1) + 12 + timecorrection;
		}
	}

        /**
         * Method to terminate call.
         */
        public void terminateCall() {
		// TODO Auto-generated method stub
		pw.println("quit");
		pw.println("exit");
		System.out.println("ending call..");
	}
/**
 * Reads the call log and loads the call events into
 * memory.
 */
	private void loadCallEvents() {
		// TODO Auto-generated method stub

		try {
			FileInputStream fstream = new FileInputStream(logfile);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String callid = "";
			String strLine;
			CallEvents Currentevent = new CallEvents();
			// Read File Line By Line
			// int i = 0;
			while ((strLine = br.readLine()) != null) {
				String args[] = strLine.split(",");
				if (!callid.equals(args[0])) {
					// Add new element to callList
					CallEvents temp = new CallEvents();
					if (!callid.equals("")) {
						callList.add(Currentevent);
					}
					callid = args[0];
					temp.Callid = callid;
					Currentevent = temp;
				}
				if (args[4].equals("<Key>")) {
					Currentevent.time.add(Integer.parseInt(args[2]));
					Currentevent.key.add(Integer.parseInt(args[5]));

				}
			}
			callList.add(Currentevent);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

        /**
         * Reads the IVR menu from database and
         * loads it into memory in a tree data 
         * structure.
         */
        public void loadIVRMenu() {
		con = new DatabaseHandler().getConnection();
		Node<String> Root = new Node<String>();
		Root.data = "0";
		int datacount = 0;
		while (!level.equals("Finish")) {
			level += "_";
			Statement st;
			try {
				st = con.createStatement();
				ResultSet res = st
						.executeQuery("select level, File, Tag from Node where level like '"
								+ level + "' order by level");
				// System.out.println("select File, Tag from Node where level like '"+
				// level + "'");
				datacount = 0;
				while (res.next()) {
					datacount++;
					if (res.getString("level") != null) {
						int childat = level.length();
						Node<String> temp = Root;
						int i = 0;
						while (i != childat) {
							i++;
							List<Node<String>> temp2 = temp.getChildren();
							int k = 0;
							while (k < temp2.size()) {

								Node<String> node = temp2.get(k);

								if (node.data.equals(res.getString("level")
										.substring(0, i))) {
									temp = node;
									break;
								}
								k++;
							}
						}
						Node<String> child = new Node<String>();
						child.data = res.getString("level");
						temp.addChild(child);

					}
				}
				if (datacount == 0) {
					level = "Finish";
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		// Retrieves the menu option at current level in IVR menu

		// Root.addChild();
		IVRmenu.setRootElement(Root);
		System.out.println(IVRmenu.toString());
	}

        

        /**
         * Method to start a new Call.
         */
        public void startCall() {
		sip_url = "sip:" + number + "@" + server_ip;
		try {
			File wd = new File("/bin");
			Process P = null;
			P = Runtime.getRuntime().exec("/bin/bash", null, wd);
			pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(P
					.getOutputStream())), true);
			is = new InputStreamReader(P.getInputStream());
			pw.println("linphonec");
			/*
			 * while (is.ready()) { System.out.print(is.read()); }
			 */
			pw.println("call " + sip_url);
			pw.println("1234");
			System.out.println("Calling..");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
        /** Method to simulate DTMF key-press on IVR.
         * @param 
         */
        public void sendDTMF(int x) {
		String s = String.valueOf(x);
		pw.println(s);
		// pw.flush();
		System.out.println(x);
		// pw.write();
	}

        /**
         * Method to simulate Audio event on IVR.
         */
        public void sendAudio() {

	}

}
